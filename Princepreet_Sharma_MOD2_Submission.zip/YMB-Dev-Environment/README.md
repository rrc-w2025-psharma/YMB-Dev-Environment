# YMB Dev Environment

COMP-4001 - Developing in a DevOps Environment

Student: Princepreet Sharma  
Student ID: 0423413

## Run the Environment

Clone this repository:

git clone https://github.com/rrc-w2025-psharma/YMB-Dev-Environment.git

Open the project folder:

cd YMB-Dev-Environment

Start the VM:

vagrant up

Open the portfolio in a browser:

http://localhost:8080

This environment uses CentOS Stream 9, Apache, Vagrant, and VirtualBox.